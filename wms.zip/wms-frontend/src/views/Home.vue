<template>
  <div class="min-h-screen bg-black">
    <!-- Hero Section -->
    <section class="relative min-h-screen flex items-center justify-center overflow-hidden pt-16">
      <!-- پس‌زمینه انیمیشن -->
      <div class="absolute inset-0">
        <div class="absolute top-1/4 right-1/4 w-96 h-96 bg-primary-400/10 rounded-full blur-3xl animate-pulse-slow"></div>
        <div class="absolute bottom-1/4 left-1/4 w-64 h-64 bg-primary-600/10 rounded-full blur-3xl animate-pulse-slow" style="animation-delay: 1.5s"></div>
      </div>

      <!-- شبکه مش -->
      <div class="absolute inset-0 opacity-5"
        style="background-image: linear-gradient(#80a1ff 1px, transparent 1px), linear-gradient(90deg, #80a1ff 1px, transparent 1px); background-size: 60px 60px;">
      </div>

      <div class="relative z-10 max-w-5xl mx-auto px-4 text-center animate-fade-in">
        <div class="inline-flex items-center gap-2 bg-primary-400/10 border border-primary-400/30 rounded-full px-4 py-2 mb-8 text-sm text-primary-400">
          <span class="w-2 h-2 rounded-full bg-primary-400 animate-pulse"></span>
          سیستم مدیریت انبار حرفه‌ای
        </div>

        <h1 class="text-5xl md:text-7xl font-black text-white mb-6 leading-tight">
          انبار خود را<br>
          <span class="text-transparent bg-clip-text bg-gradient-to-r from-primary-300 to-primary-500">
            هوشمند مدیریت
          </span><br>
          کنید
        </h1>

        <p class="text-xl text-gray-400 mb-12 max-w-2xl mx-auto leading-relaxed">
          با سیستم مدیریت انبار ما، موجودی کالاها، گزارش‌ها و عملیات انبار
          خود را به سادگی و با دقت بالا مدیریت کنید.
        </p>

        <div class="flex flex-col sm:flex-row gap-4 justify-center">
          <RouterLink to="/register" class="btn-primary text-lg px-8 py-4">
            شروع رایگان
          </RouterLink>
          <RouterLink to="/about" class="btn-secondary text-lg px-8 py-4">
            بیشتر بدانید
          </RouterLink>
        </div>
      </div>

      <!-- فلش پایین -->
      <div class="absolute bottom-8 left-1/2 -translate-x-1/2 animate-bounce text-gray-600">
        <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
          <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 9l-7 7-7-7"/>
        </svg>
      </div>
    </section>

    <!-- آمار -->
    <section class="py-16 border-t border-gray-800">
      <div class="max-w-7xl mx-auto px-4">
        <div class="grid grid-cols-2 md:grid-cols-4 gap-8">
          <div v-for="stat in stats" :key="stat.label" class="text-center">
            <div class="text-4xl font-black text-primary-400 mb-2">{{ stat.value }}</div>
            <div class="text-gray-400 text-sm">{{ stat.label }}</div>
          </div>
        </div>
      </div>
    </section>

    <!-- ویژگی‌ها -->
    <section class="py-20">
      <div class="max-w-7xl mx-auto px-4">
        <div class="text-center mb-16">
          <h2 class="text-4xl font-bold text-white mb-4">ویژگی‌های کلیدی</h2>
          <p class="text-gray-400 text-lg">همه چیزی که برای مدیریت حرفه‌ای انبار نیاز دارید</p>
        </div>

        <div class="grid md:grid-cols-3 gap-6">
          <div v-for="feature in features" :key="feature.title" class="card group hover:border-primary-400/50 transition-all duration-300">
            <div class="w-12 h-12 rounded-xl bg-primary-400/10 flex items-center justify-center mb-4 group-hover:bg-primary-400/20 transition-colors">
              <component :is="feature.icon" class="w-6 h-6 text-primary-400" />
            </div>
            <h3 class="text-white font-bold text-lg mb-2">{{ feature.title }}</h3>
            <p class="text-gray-400 text-sm leading-relaxed">{{ feature.desc }}</p>
          </div>
        </div>
      </div>
    </section>

    <!-- CTA -->
    <section class="py-20">
      <div class="max-w-4xl mx-auto px-4 text-center">
        <div class="glass p-12 relative overflow-hidden">
          <div class="absolute inset-0 bg-gradient-to-br from-primary-400/5 to-transparent"></div>
          <div class="relative z-10">
            <h2 class="text-4xl font-bold text-white mb-4">آماده شروع هستید؟</h2>
            <p class="text-gray-400 mb-8">همین حالا ثبت‌نام کنید و انبار خود را مدیریت کنید</p>
            <RouterLink to="/register" class="btn-primary text-lg px-10 py-4">
              ثبت‌نام رایگان
            </RouterLink>
          </div>
        </div>
      </div>
    </section>
  </div>
</template>

<script setup>
import { h } from 'vue'

const stats = [
  { value: '+۱۰۰۰', label: 'کاربر فعال' },
  { value: '+۵۰K',  label: 'کالا ثبت‌شده' },
  { value: '۹۹.۹٪', label: 'آپتایم' },
  { value: '۲۴/۷',  label: 'پشتیبانی' },
]

const BoxIcon   = { render: () => h('svg', { fill: 'none', stroke: 'currentColor', viewBox: '0 0 24 24', class: 'w-6 h-6' }, [h('path', { 'stroke-linecap': 'round', 'stroke-linejoin': 'round', 'stroke-width': '2', d: 'M20 7l-8-4-8 4m16 0l-8 4m8-4v10l-8 4m0-10L4 7m8 4v10M4 7v10l8 4' })]) }
const ChartIcon = { render: () => h('svg', { fill: 'none', stroke: 'currentColor', viewBox: '0 0 24 24', class: 'w-6 h-6' }, [h('path', { 'stroke-linecap': 'round', 'stroke-linejoin': 'round', 'stroke-width': '2', d: 'M9 19v-6a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2a2 2 0 002-2zm0 0V9a2 2 0 012-2h2a2 2 0 012 2v10m-6 0a2 2 0 002 2h2a2 2 0 002-2m0 0V5a2 2 0 012-2h2a2 2 0 012 2v14a2 2 0 01-2 2h-2a2 2 0 01-2-2z' })]) }
const LockIcon  = { render: () => h('svg', { fill: 'none', stroke: 'currentColor', viewBox: '0 0 24 24', class: 'w-6 h-6' }, [h('path', { 'stroke-linecap': 'round', 'stroke-linejoin': 'round', 'stroke-width': '2', d: 'M12 15v2m-6 4h12a2 2 0 002-2v-6a2 2 0 00-2-2H6a2 2 0 00-2 2v6a2 2 0 002 2zm10-10V7a4 4 0 00-8 0v4h8z' })]) }

const features = [
  { icon: BoxIcon,   title: 'مدیریت کامل موجودی',  desc: 'افزودن، ویرایش و حذف کالاها با اطلاعات کامل شامل کد، قیمت، تعداد و توضیحات.' },
  { icon: ChartIcon, title: 'گزارش‌های لحظه‌ای',   desc: 'مشاهده آمار و گزارش‌های دقیق از وضعیت موجودی، ارزش کل و کالاهای کم‌موجود.' },
  { icon: LockIcon,  title: 'امنیت و احراز هویت', desc: 'سیستم احراز هویت پیشرفته با رمزگذاری امن و مدیریت دسترسی کاربران.' },
]
</script>