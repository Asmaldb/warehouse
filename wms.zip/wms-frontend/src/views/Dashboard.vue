<template>
  <div class="min-h-screen bg-black pt-16">
    <div class="max-w-7xl mx-auto px-4 py-10">
      <!-- خوشامدگویی -->
      <div class="mb-10 animate-fade-in">
        <h1 class="text-3xl font-bold text-white">
          خوش آمدید، <span class="text-primary-400">{{ authStore.user?.name }}</span> 👋
        </h1>
        <p class="text-gray-400 mt-1">نمای کلی انبار شما</p>
      </div>

      <!-- کارت‌های آمار -->
      <div class="grid grid-cols-2 lg:grid-cols-4 gap-4 mb-10">
        <div v-for="(stat, i) in statCards" :key="stat.label"
          class="card animate-slide-up"
          :style="{ animationDelay: `${i * 0.1}s` }">
          <div class="flex items-center justify-between mb-3">
            <span class="text-gray-400 text-sm">{{ stat.label }}</span>
            <div class="w-8 h-8 rounded-lg flex items-center justify-center" :class="stat.bg">
              <component :is="stat.icon" class="w-4 h-4" :class="stat.color" />
            </div>
          </div>
          <div class="text-2xl font-bold text-white">
            <span v-if="statsLoading" class="text-gray-600">--</span>
            <span v-else>{{ stat.value }}</span>
          </div>
        </div>
      </div>

      <!-- دسترسی سریع -->
      <div class="grid md:grid-cols-2 gap-4">
        <div class="card">
          <h2 class="text-lg font-bold text-white mb-4">دسترسی سریع</h2>
          <div class="space-y-3">
            <RouterLink to="/products" class="flex items-center gap-3 p-3 rounded-lg bg-gray-800 hover:bg-gray-700 transition-colors group">
              <div class="w-8 h-8 rounded-lg bg-primary-400/10 flex items-center justify-center group-hover:bg-primary-400/20 transition-colors">
                <svg class="w-4 h-4 text-primary-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M20 7l-8-4-8 4m16 0l-8 4m8-4v10l-8 4m0-10L4 7m8 4v10M4 7v10l8 4"/>
                </svg>
              </div>
              <span class="text-white text-sm font-medium">مدیریت کالاها</span>
              <svg class="w-4 h-4 text-gray-500 mr-auto" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 19l-7-7 7-7"/>
              </svg>
            </RouterLink>
          </div>
        </div>

        <div class="card">
          <h2 class="text-lg font-bold text-white mb-4">وضعیت سیستم</h2>
          <div class="space-y-3">
            <div class="flex items-center justify-between">
              <span class="text-gray-400 text-sm">وضعیت API</span>
              <span class="flex items-center gap-1.5 text-green-400 text-sm">
                <span class="w-2 h-2 rounded-full bg-green-400 animate-pulse"></span>
                آنلاین
              </span>
            </div>
            <div class="flex items-center justify-between">
              <span class="text-gray-400 text-sm">کاربر جاری</span>
              <span class="text-white text-sm">{{ authStore.user?.email }}</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref, onMounted, h } from 'vue'
import { useAuthStore } from '@/stores/auth'
import { productsApi } from '@/api/products'

const authStore    = useAuthStore()
const statsLoading = ref(true)
const stats        = ref({ total_products: 0, total_quantity: 0, total_value: 0, low_stock: 0 })

const BoxIcon    = { render: () => h('svg', { fill: 'none', stroke: 'currentColor', viewBox: '0 0 24 24' }, [h('path', { 'stroke-linecap': 'round', 'stroke-linejoin': 'round', 'stroke-width': '2', d: 'M20 7l-8-4-8 4m16 0l-8 4m8-4v10l-8 4m0-10L4 7m8 4v10M4 7v10l8 4' })]) }
const LayersIcon = { render: () => h('svg', { fill: 'none', stroke: 'currentColor', viewBox: '0 0 24 24' }, [h('path', { 'stroke-linecap': 'round', 'stroke-linejoin': 'round', 'stroke-width': '2', d: 'M12 2L2 7l10 5 10-5-10-5zM2 17l10 5 10-5M2 12l10 5 10-5' })]) }
const CashIcon   = { render: () => h('svg', { fill: 'none', stroke: 'currentColor', viewBox: '0 0 24 24' }, [h('path', { 'stroke-linecap': 'round', 'stroke-linejoin': 'round', 'stroke-width': '2', d: 'M12 8c-1.657 0-3 .895-3 2s1.343 2 3 2 3 .895 3 2-1.343 2-3 2m0-8c1.11 0 2.08.402 2.599 1M12 8V7m0 1v8m0 0v1m0-1c-1.11 0-2.08-.402-2.599-1M21 12a9 9 0 11-18 0 9 9 0 0118 0z' })]) }
const WarnIcon   = { render: () => h('svg', { fill: 'none', stroke: 'currentColor', viewBox: '0 0 24 24' }, [h('path', { 'stroke-linecap': 'round', 'stroke-linejoin': 'round', 'stroke-width': '2', d: 'M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z' })]) }

const statCards = ref([
  { label: 'کل کالاها',    value: '0', icon: BoxIcon,    bg: 'bg-blue-500/10',   color: 'text-blue-400'   },
  { label: 'موجودی کل',   value: '0', icon: LayersIcon, bg: 'bg-green-500/10',  color: 'text-green-400'  },
  { label: 'ارزش انبار',   value: '0', icon: CashIcon,   bg: 'bg-yellow-500/10', color: 'text-yellow-400' },
  { label: 'کم‌موجود',     value: '0', icon: WarnIcon,   bg: 'bg-red-500/10',    color: 'text-red-400'    },
])

onMounted(async () => {
  try {
    const res = await productsApi.getStats()
    stats.value = res.data
    statCards.value[0].value = res.data.total_products.toString()
    statCards.value[1].value = res.data.total_quantity.toString()
    statCards.value[2].value = Number(res.data.total_value).toLocaleString('fa-IR') + ' تومان'
    statCards.value[3].value = res.data.low_stock.toString()
  } finally {
    statsLoading.value = false
  }
})
</script>