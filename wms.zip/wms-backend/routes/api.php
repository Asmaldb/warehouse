use App\Http\Controllers\AuthController;
use App\Http\Controllers\ContactController;
use App\Http\Controllers\ProductController;
use Illuminate\Support\Facades\Route;

// مسیرهای عمومی
Route::post('/register', [AuthController::class, 'register']);
Route::post('/login',    [AuthController::class, 'login']);
Route::post('/contact',  [ContactController::class, 'store']);

// مسیرهای محافظت‌شده
Route::middleware('auth:sanctum')->group(function () {
    Route::post('/logout', [AuthController::class, 'logout']);
    Route::get('/me',      [AuthController::class, 'me']);

    // محصولات
    Route::get('/products/stats', [ProductController::class, 'stats']);
    Route::apiResource('/products', ProductController::class);
});